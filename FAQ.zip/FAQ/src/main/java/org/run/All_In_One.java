/**
 * 
 */
package org.run;

/**
 * @author a1354
 *
 */
public class All_In_One {

}
