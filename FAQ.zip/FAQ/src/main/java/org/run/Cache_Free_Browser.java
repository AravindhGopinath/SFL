package org.run;

import org.base.BaseClass;
import org.testng.annotations.Test;

public class Cache_Free_Browser extends BaseClass{

	@Test
	
	public void browserLaunch() {
		
		launchBrowser("chrome");
	}
	
	
}
