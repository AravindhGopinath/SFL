package org.run;

import java.util.Scanner;

import org.base.BaseClass;
import org.testng.annotations.Test;

public class cacheless_browse extends BaseClass {

	@Test
	public void browserLaunch() {

		System.out.println("Enter Browser name");
		Scanner s = new Scanner(System.in);
		String browser_name = s.next();
		if (browser_name.equals("chrome")) {

			System.out.println("Chrome is launching");

		} else if (browser_name.equals("firefox") || browser_name.equals("ie")) {

			System.out.println("Firefox is launching");

		}

		else {

			System.out.println("Edge is launching");

		}

		launchBrowser(browser_name);

	}

}
